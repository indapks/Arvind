
Mali-G57 MC2