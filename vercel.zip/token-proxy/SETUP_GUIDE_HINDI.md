# 🚀 Shem App - Premium Token Proxy Setup Guide

## Kya Ye Setup Karti Hai?

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  User Login (Koi Bhi Account)                               │
│              ↓                                               │
│  Token Automatically Capture Ho Jati Hai                    │
│              ↓                                               │
│  Premium Token Inject Hoti Hai                              │
│              ↓                                               │
│  Koi Bhi Account = Premium Features 🎉                      │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 📋 Step 1: Vercel Account Setup

### ✅ Agar Account Nahi Hai:
1. **https://vercel.com** pe jaao
2. GitHub se sign up karo (easiest)
3. Free account banao

### ✅ Agar Account Hai:
- Seedha Step 2 par jaao

---

## 📦 Step 2: Code Upload Karna

### **Option A: GitHub Se (Recommended)**

```bash
# 1. GitHub par new repo banao: "shem-token-proxy"
# 2. Apne computer mein folder banao
mkdir shem-token-proxy
cd shem-token-proxy

# 3. Git initialize karo
git init
git config user.email "your-email@gmail.com"
git config user.name "Your Name"

# 4. Ye 3 files add karo:
# - api/index.js (humne di thi)
# - vercel.json
# - package.json

# 5. Push karo GitHub ko
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/shem-token-proxy.git
git push -u origin main
```

### **Option B: Direct Upload (Agar GitHub nahi hai)**

1. **Vercel Dashboard** mein login karo
2. **"Add New"** → **"Project"** click karo
3. **"Import Git Repository"** ke bajay **"Clone Template"** select karo
4. Files copy-paste karo

---

## 🔧 Step 3: Vercel Par Deploy Karna

### **Automatic Deployment:**

1. **https://vercel.com/dashboard** open karo
2. **"Add New"** → **"Project"** click karo
3. Apna **GitHub repo select** karo
4. **"Deploy"** button click karo
5. ✅ **Done!** Proxy live ho gaya!

**Tumhara proxy URL milega:**
```
https://your-project-name.vercel.app
```

---

## 🔑 Step 4: Token Capture Karna

### **Process:**

1. **Apna phone/device open karo**
2. **Original Shem App ke API को proxy se replace karo:**
   
   ```
   Replace This:    https://prod.api.shem.apisaranyu.in
   With This:       https://your-project-name.vercel.app
   ```
   
   *(Network settings mein या app config mein)*

3. **App mein login karo:**
   - कोई भी account से login कर सकते हो
   - Premium token automatically capture हो जाएगी

4. **Token Status Check करो:**
   ```
   https://your-project-name.vercel.app/token-status
   ```

---

## 🎯 Step 5: How It Works

### **Login Request:**
```
App → Proxy → Real API (prod.api.shem.apisaranyu.in)
      ↓
   Token automatically extract ho jati hai
      ↓
   Saved in proxy memory
```

### **Future Requests:**
```
App → Proxy → Real API
      ↓
   Saved premium token inject hoti hai
      ↓
   API sochta hai: "Ye toh premium account hai!" 
      ↓
   Premium features unlock! 🎉
```

---

## 📡 Important Endpoints

| URL | Purpose |
|-----|---------|
| `https://proxy.app/token-status` | Current token dekho |
| `https://proxy.app/reset-token` | Token clear karo |
| `https://proxy.app/capture-token` | Manual token capture |

---

## ⚙️ Kaise Proxy Setup Kare App Mein

### **Android App Mein (Custom Network Setup):**

Agar app custom proxy support karta hai:

1. **Settings** → **Network Configuration**
2. **Proxy URL:** `https://your-project-name.vercel.app`
3. **Port:** `443` (HTTPS ke liye)

### **Android (Agar WiFi Proxy Support Hai):**

1. **WiFi Network Edit** → **Advanced Options**
2. **Proxy:** `your-project-name.vercel.app`
3. **Port:** `8080` (agar available ho)

---

## 🐛 Troubleshooting

### **❌ Problem: "Proxy connection failed"**
**Solution:**
- Vercel deployment check karo: `https://vercel.com/dashboard`
- Log dekho: **"View Function Logs"**
- Make sure target URL sahi hai

### **❌ Problem: "Token not captured"**
**Solution:**
- Login request properly proxy se jaa raha hai check karo
- `/token-status` endpoint par jaao
- App logs dekho (Logcat)

### **❌ Problem: "401 Unauthorized"**
**Solution:**
- Premium account ka token saved nahi ho raha
- App ko logout aur login dobara karo
- Token manually `/capture-token` se inject karo

---

## 📱 Mobile App Modification (Optional)

**Agar app modify karna possible ho:**

```java
// Android Example - Intercept HTTP Client
OkHttpClient client = new OkHttpClient.Builder()
    .addInterceptor(new Interceptor() {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request original = chain.request();
            
            // Replace base URL
            HttpUrl url = original.url()
                .newBuilder()
                .host("your-proxy.vercel.app")
                .build();
            
            return chain.proceed(original.newBuilder().url(url).build());
        }
    })
    .build();
```

---

## ✅ Verification Checklist

- [ ] Vercel account create kiya
- [ ] GitHub repo mein code push kiya
- [ ] Vercel par deploy complete hua
- [ ] Proxy URL mil gaya
- [ ] App ke proxy URL update kiye
- [ ] Login test kiya
- [ ] Token captured show ho raha hai
- [ ] `/token-status` check kiya

---

## 🎉 Success!

Jab token successfully capture ho jaye:

1. **Koi bhi account** se login karo
2. **Premium features** automatically available honge
3. **Streaming/Content** unlimited chalega
4. Enjoy! 🚀

---

## 💡 Advanced Tips

### **Multiple Tokens Store Karna:**
Code modify kar sakte ho stored tokens ka history keep karne ke liye.

### **Token Expiry Handling:**
Automatically refresh token logic add kar sakte ho.

### **Analytics:**
Kaunse endpoints use ho rahe hain, logs dekh sakte ho Vercel dashboard mein.

---

## ❓ Questions?

- **Vercel Issues:** https://vercel.com/support
- **Node.js Help:** https://nodejs.org/docs
- **Network Proxy:** Search "HTTP proxy setup Android"

---

**Happy Streaming! 🎬✨**
